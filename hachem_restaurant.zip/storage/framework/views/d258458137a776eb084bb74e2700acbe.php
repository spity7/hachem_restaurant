

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">Create Employee</div>

        <div class="card-body">
            <form action="<?php echo e(route('employees.store')); ?>" method="post">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label class="required" for="name">Name</label>
                    <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name"
                        id="name" value="<?php echo e(old('name')); ?>" required>
                    <?php if($errors->has('name')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('name')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label class="required" for="phone">Phone</label>
                    <input class="form-control <?php echo e($errors->has('phone') ? 'is-invalid' : ''); ?>" type="text"
                        name="phone" id="phone" value="<?php echo e(old('phone')); ?>">
                    <?php if($errors->has('phone')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('phone')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label class="required" for="address">Address</label>
                    <input class="form-control <?php echo e($errors->has('address') ? 'is-invalid' : ''); ?>" type="address"
                        name="address" id="address" value="<?php echo e(old('address')); ?>">
                    <?php if($errors->has('address')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('address')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label class="required" for="initial_salary">الراتب</label>
                    <input class="form-control <?php echo e($errors->has('initial_salary') ? 'is-invalid' : ''); ?>"
                        type="number" name="initial_salary" id="initial_salary" value="<?php echo e(old('initial_salary')); ?>"
                        required>
                    <?php if($errors->has('initial_salary')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('initial_salary')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label for="notes">ملاحظات</label>
                    <input class="form-control <?php echo e($errors->has('notes') ? 'is-invalid' : ''); ?>" type="text"
                        name="notes" id="notes" value="<?php echo e(old('notes')); ?>">
                    <?php if($errors->has('notes')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('notes')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <button class="btn btn-primary" type="submit">
                        Save
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROJECTS\hachem_restaurant\resources\views/employees/create.blade.php ENDPATH**/ ?>