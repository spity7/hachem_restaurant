<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($product->current_quantity <= $product->quantity_alert): ?>
            <div class="card" style="width: 19rem; font-weight: bold;">
                <div class="card-header text-danger">!!! تنبيه !!!</div>

                <div class="card-body">
                    إنتبه الى : <?php echo e($product->name); ?>

                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <div class="card" style="width: 16rem; font-weight: bold;">
        <div class="card-header">عدد الموظفين: <?php echo e($employees_count); ?></div>

        <div class="card-body">
            مجموع الرواتب: <?php echo e($employees_total_salaries); ?>

            <br><br>
            <span class="text-danger">
                مجموع السلف: <?php echo e($withdrawals_total); ?>

            </span>
            <br><br>
            <span class="text-success">
                باقي الرواتب: <?php echo e($salaries_rest); ?>

            </span>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROJECTS\hachem_restaurant\resources\views/home.blade.php ENDPATH**/ ?>