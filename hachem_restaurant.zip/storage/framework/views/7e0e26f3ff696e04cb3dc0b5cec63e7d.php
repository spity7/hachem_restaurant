

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">Edit Product</div>

        <div class="card-body">
            <form action="<?php echo e(route('products.update', $product)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-group">
                    <label class="required" for="name">Name</label>
                    <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name"
                        id="name" value="<?php echo e(old('name', $product->name)); ?>" required>
                    <?php if($errors->has('name')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('name')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label class="required" for="quantity_alert">الإنذار</label>
                    <input class="form-control <?php echo e($errors->has('quantity_alert') ? 'is-invalid' : ''); ?>" type="text"
                        name="quantity_alert" id="quantity_alert"
                        value="<?php echo e(old('quantity_alert', $product->quantity_alert)); ?>">
                    <?php if($errors->has('quantity_alert')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('quantity_alert')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <button class="btn btn-primary" type="submit">
                        Save
                    </button>
                </div>
            </form>
        </div>
    </div>

    <hr>

    <div class="card">
        <div class="card-header text-success">إضافة كمية</div>

        <div class="card-body">
            <form action="<?php echo e(route('productDetails.addIncrease', $product)); ?>" method="post">
                <?php echo csrf_field(); ?>

                <div class="form-group text-success">
                    <label class="required" for="increase">الكمية:</label>
                    <input class="form-control <?php echo e($errors->has('increase') ? 'is-invalid' : ''); ?>" type="number"
                        name="increase" id="increase" value="<?php echo e(old('increase')); ?>" required>
                    <?php if($errors->has('increase')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('increase')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label class="required" for="price">Price:</label>
                    <input class="form-control <?php echo e($errors->has('price') ? 'is-invalid' : ''); ?>" type="text"
                        name="price" id="price" value="<?php echo e(old('price')); ?>">
                    <?php if($errors->has('price')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('price')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label class="required" for="notes">Notes:</label>
                    <input class="form-control <?php echo e($errors->has('notes') ? 'is-invalid' : ''); ?>" type="text"
                        name="notes" id="notes" value="<?php echo e(old('notes')); ?>">
                    <?php if($errors->has('notes')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('notes')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <button class="btn btn-primary" type="submit">
                        Save
                    </button>
                </div>
            </form>
        </div>
    </div>

    <hr>

    <div class="card">
        <div class="card-header text-danger">سحب كمية</div>

        <div class="card-body">
            <form action="<?php echo e(route('productDetails.addDecrease', $product)); ?>" method="post">
                <?php echo csrf_field(); ?>

                <div class="form-group text-danger">
                    <label class="required" for="decrease">الكمية:</label>
                    <input class="form-control <?php echo e($errors->has('decrease') ? 'is-invalid' : ''); ?>" type="number"
                        name="decrease" id="decrease" value="<?php echo e(old('decrease')); ?>" required>
                    <?php if($errors->has('decrease')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('decrease')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label class="required" for="notes">Notes:</label>
                    <input class="form-control <?php echo e($errors->has('notes') ? 'is-invalid' : ''); ?>" type="text"
                        name="notes" id="notes" value="<?php echo e(old('notes')); ?>">
                    <?php if($errors->has('notes')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('notes')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <button class="btn btn-primary" type="submit">
                        Save
                    </button>
                </div>
            </form>
        </div>
    </div>

    <hr>

    <div class="card">
        <div class="card-header">المعاملات السابقة</div>

        <?php if(session('status')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <div class="card-body">
            <table class="table table-responsive-sm">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th class="text-success">الكمية المضافة</th>
                        <th class="text-danger">الكمية المسحوبة</th>
                        <th>السعر</th>
                        <th>Notes</th>
                        <th>التاريخ</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($detail->decrease && !$detail->increase): ?>
                            <tr class="table-danger">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($detail->increase); ?></td>
                                <td><?php echo e($detail->decrease); ?></td>
                                <td><?php echo e($detail->price); ?></td>
                                <td><?php echo e($detail->notes); ?></td>
                                <td><?php echo e($detail->created_at->format('Y-m-d')); ?></td>
                                <td>
                                    <form action="<?php echo e(route('productDetails.destroy', $detail)); ?>" method="POST"
                                        onsubmit="return confirm('Are your sure?');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="submit" class="btn btn-sm btn-danger" value="Delete">
                                    </form>
                                </td>
                            </tr>
                        <?php elseif($detail->increase && !$detail->decrease): ?>
                            <tr class="table-success">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($detail->increase); ?></td>
                                <td><?php echo e($detail->decrease); ?></td>
                                <td><?php echo e($detail->price); ?></td>
                                <td><?php echo e($detail->notes); ?></td>
                                <td><?php echo e($detail->created_at->format('Y-m-d')); ?></td>
                                <td>
                                    <form action="<?php echo e(route('productDetails.destroy', $detail)); ?>" method="POST"
                                        onsubmit="return confirm('Are your sure?');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="submit" class="btn btn-sm btn-danger" value="Delete">
                                    </form>
                                </td>
                            </tr>
                        <?php else: ?>
                            <tr class="table-secondary">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($detail->increase); ?></td>
                                <td><?php echo e($detail->decrease); ?></td>
                                <td><?php echo e($detail->price); ?></td>
                                <td><?php echo e($detail->notes); ?></td>
                                <td><?php echo e($detail->created_at->format('Y-m-d')); ?></td>
                                <td>
                                    <form action="<?php echo e(route('productDetails.destroy', $detail)); ?>" method="POST"
                                        onsubmit="return confirm('Are your sure?');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="submit" class="btn btn-sm btn-danger" value="Delete">
                                    </form>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROJECTS\hachem_restaurant\resources\views/products/edit.blade.php ENDPATH**/ ?>