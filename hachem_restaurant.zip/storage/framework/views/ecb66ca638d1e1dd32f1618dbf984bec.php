

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">Create Product</div>

        <div class="card-body">
            <form action="<?php echo e(route('products.store')); ?>" method="post">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label class="required" for="name">Name:</label>
                    <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name"
                        id="name" value="<?php echo e(old('name')); ?>" required>
                    <?php if($errors->has('name')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('name')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label class="required" for="increase">الكمية:</label>
                    <input class="form-control <?php echo e($errors->has('increase') ? 'is-invalid' : ''); ?>" type="number"
                        name="increase" id="increase" value="<?php echo e(old('increase')); ?>" required>
                    <?php if($errors->has('increase')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('increase')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label class="required" for="price">السعر:</label>
                    <input class="form-control <?php echo e($errors->has('price') ? 'is-invalid' : ''); ?>" type="number"
                        name="price" id="price" value="<?php echo e(old('price')); ?>">
                    <?php if($errors->has('price')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('price')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label class="required" for="quantity_alert">الإنذار:</label>
                    <input class="form-control <?php echo e($errors->has('quantity_alert') ? 'is-invalid' : ''); ?>" type="number"
                        name="quantity_alert" id="quantity_alert" value="<?php echo e(old('quantity_alert')); ?>">
                    <?php if($errors->has('quantity_alert')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('quantity_alert')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label for="notes">Notes:</label>
                    <input class="form-control <?php echo e($errors->has('notes') ? 'is-invalid' : ''); ?>" type="text"
                        name="notes" id="notes" value="<?php echo e(old('notes')); ?>">
                    <?php if($errors->has('notes')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('notes')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <button class="btn btn-primary" type="submit">
                        Save
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROJECTS\hachem_restaurant\resources\views/products/create.blade.php ENDPATH**/ ?>