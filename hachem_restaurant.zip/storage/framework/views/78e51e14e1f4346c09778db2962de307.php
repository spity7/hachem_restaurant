

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">Edit Supplier</div>

        <div class="card-body">
            <form action="<?php echo e(route('suppliers.update', $supplier)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-group">
                    <label class="required" for="name">Name:</label>
                    <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name"
                        id="name" value="<?php echo e(old('name', $supplier->name)); ?>" required>
                    <?php if($errors->has('name')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('name')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label class="required" for="phone">Phone:</label>
                    <input class="form-control <?php echo e($errors->has('phone') ? 'is-invalid' : ''); ?>" type="text"
                        name="phone" id="phone" value="<?php echo e(old('phone', $supplier->phone)); ?>">
                    <?php if($errors->has('phone')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('phone')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label class="required" for="address">Address:</label>
                    <input class="form-control <?php echo e($errors->has('address') ? 'is-invalid' : ''); ?>" type="text"
                        name="address" id="address" value="<?php echo e(old('address', $supplier->address)); ?>">
                    <?php if($errors->has('address')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('address')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label class="required" for="shop_name">Shop Name:</label>
                    <input class="form-control <?php echo e($errors->has('shop_name') ? 'is-invalid' : ''); ?>" type="integer"
                        name="shop_name" id="shop_name" value="<?php echo e(old('shop_name', $supplier->shop_name)); ?>">
                    <?php if($errors->has('shop_name')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('shop_name')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label for="notes">Notes</label>
                    <input class="form-control <?php echo e($errors->has('notes') ? 'is-invalid' : ''); ?>" type="text"
                        name="notes" id="notes" value="<?php echo e(old('notes', $supplier->notes)); ?>">
                    <?php if($errors->has('notes')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('notes')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <button class="btn btn-primary" type="submit">
                        Save
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROJECTS\hachem_restaurant\resources\views/suppliers/edit.blade.php ENDPATH**/ ?>