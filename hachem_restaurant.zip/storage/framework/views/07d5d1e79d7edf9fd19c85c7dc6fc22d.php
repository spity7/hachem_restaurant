

<?php $__env->startSection('content'); ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('employees.create')); ?>">
                Create Employee
            </a>
        </div>
    </div>

    <div class="card">
        <div class="card-header">Employees list</div>

        <?php if(session('status')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <div class="card-body">
            <table class="table table-responsive-sm">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>
                            <form action="<?php echo e(route('withdrawals.destroyAll')); ?>" method="POST"
                                onsubmit="return confirm('Are your sure?');" style="display: inline-block;">
                                <input type="hidden" name="_method" value="DELETE">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input type="submit" class="btn btn-sm btn-danger" value="مسح كل السلف">
                            </form>
                        </th>
                        <th>Name</th>
                        <th>الراتب الأساسي</th>
                        <th>السلف</th>
                        <th>باقي الراتب</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody class="table-secondary">
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <form action="<?php echo e(route('withdrawals.destroyMultiple', $employee)); ?>" method="POST"
                                    onsubmit="return confirm('Are your sure?');" style="display: inline-block;">
                                    <input type="hidden" name="_method" value="DELETE">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <input type="submit" class="btn btn-sm btn-danger" value="مسح السلفة">
                                </form>
                            </td>
                            <td><?php echo e($employee->name); ?></td>
                            <td><?php echo e($employee->initial_salary); ?></td>
                            <td><?php echo e($employee->withdrawals_total); ?></td>
                            <td><?php echo e($employee->current_salary); ?></td>
                            <td>
                                <a class="btn btn-sm btn-info" href="<?php echo e(route('employees.edit', $employee)); ?>">
                                    Edit
                                </a>
                                <form action="<?php echo e(route('employees.destroy', $employee)); ?>" method="POST"
                                    onsubmit="return confirm('Are your sure?');" style="display: inline-block;">
                                    <input type="hidden" name="_method" value="DELETE">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <input type="submit" class="btn btn-sm btn-danger" value="Delete">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROJECTS\hachem_restaurant\resources\views/employees/index.blade.php ENDPATH**/ ?>