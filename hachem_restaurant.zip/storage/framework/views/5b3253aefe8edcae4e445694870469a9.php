<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">Contact information</div>

        <div class="card-body">
            <form action="<?php echo e(route('profile.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label class="required" for="first_name">First name</label>
                    <input class="form-control <?php echo e($errors->has('first_name') ? 'is-invalid' : ''); ?>" type="text"
                        name="first_name" id="first_name" value="<?php echo e(old('first_name', auth()->user()->first_name)); ?>"
                        required>
                    <?php if($errors->has('first_name')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('first_name')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label class="required" for="last_name">Last name</label>
                    <input class="form-control <?php echo e($errors->has('last_name') ? 'is-invalid' : ''); ?>" type="text"
                        name="last_name" id="last_name" value="<?php echo e(old('last_name', auth()->user()->last_name)); ?>" required>
                    <?php if($errors->has('last_name')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('last_name')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label class="required" for="address">Address</label>
                    <input class="form-control <?php echo e($errors->has('address') ? 'is-invalid' : ''); ?>" type="text"
                        name="address" id="address" value="<?php echo e(old('address', auth()->user()->address)); ?>">
                    <?php if($errors->has('address')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('address')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label class="required" for="phone_number">Phone number</label>
                    <input class="form-control <?php echo e($errors->has('phone_number') ? 'is-invalid' : ''); ?>" type="text"
                        name="phone_number" id="phone_number"
                        value="<?php echo e(old('phone_number', auth()->user()->phone_number)); ?>">
                    <?php if($errors->has('phone_number')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('phone_number')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <button class="btn btn-primary" type="submit">
                    Save
                </button>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header">Change password</div>

        <div class="card-body">
            <form action="<?php echo e(route('profile.changePassword')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label class="required" for="old_password">Old password</label>
                    <input class="form-control <?php echo e($errors->has('old_password') ? 'is-invalid' : ''); ?>" type="password"
                        name="old_password" id="old_password" required>
                    <?php if($errors->has('old_password')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('old_password')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label class="required" for="new_password">New password</label>
                    <input class="form-control <?php echo e($errors->has('new_password') ? 'is-invalid' : ''); ?>" type="password"
                        name="new_password" id="new_password" required>
                    <?php if($errors->has('new_password')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('new_password')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label class="required" for="new_password_confirmation">Confirm new password</label>
                    <input class="form-control <?php echo e($errors->has('new_password_confirmation') ? 'is-invalid' : ''); ?>"
                        type="password" name="new_password_confirmation" id="new_password_confirmation" required>
                    <?php if($errors->has('new_password_confirmation')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('new_password_confirmation')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <button class="btn btn-primary" type="submit">
                    Save
                </button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROJECTS\hachem_restaurant\resources\views/profile/index.blade.php ENDPATH**/ ?>