

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">تعديل الموظف</div>

        <div class="card-body">
            <form action="<?php echo e(route('employees.update', $employee)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-group">
                    <label class="required" for="name">Name</label>
                    <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name"
                        id="name" value="<?php echo e(old('name', $employee->name)); ?>" required>
                    <?php if($errors->has('name')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('name')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label class="required" for="phone">Phone</label>
                    <input class="form-control <?php echo e($errors->has('phone') ? 'is-invalid' : ''); ?>" type="text"
                        name="phone" id="phone" value="<?php echo e(old('phone', $employee->phone)); ?>">
                    <?php if($errors->has('phone')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('phone')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label class="required" for="address">Address</label>
                    <input class="form-control <?php echo e($errors->has('address') ? 'is-invalid' : ''); ?>" type="text"
                        name="address" id="address" value="<?php echo e(old('address', $employee->address)); ?>">
                    <?php if($errors->has('address')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('address')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group text-success">
                    <label class="required" for="initial_salary">الراتب الأساسي</label>
                    <input class="form-control <?php echo e($errors->has('initial_salary') ? 'is-invalid' : ''); ?>" type="integer"
                        name="initial_salary" id="initial_salary"
                        value="<?php echo e(old('initial_salary', $employee->initial_salary)); ?>" required>
                    <?php if($errors->has('initial_salary')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('initial_salary')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group text-danger">
                    <label for="withdrawals">مجموع السلف</label>
                    <input class="form-control <?php echo e($errors->has('withdrawals') ? 'is-invalid' : ''); ?>" type="integer"
                        name="withdrawals" id="withdrawals" value="<?php echo e(old('withdrawals', $employee->withdrawalsTotal)); ?>"
                        readonly>
                    <?php if($errors->has('withdrawals')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('withdrawals')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group text-success">
                    <label for="current_salary">باقي الراتب</label>
                    <input class="form-control <?php echo e($errors->has('current_salary') ? 'is-invalid' : ''); ?>" type="integer"
                        name="current_salary" id="current_salary"
                        value="<?php echo e(old('current_salary', $employee->current_salary)); ?>" readonly>
                    <?php if($errors->has('current_salary')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('current_salary')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label for="notes">Notes</label>
                    <input class="form-control <?php echo e($errors->has('notes') ? 'is-invalid' : ''); ?>" type="text"
                        name="notes" id="notes" value="<?php echo e(old('notes', $employee->notes)); ?>">
                    <?php if($errors->has('notes')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('notes')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <button class="btn btn-primary" type="submit">
                        Save
                    </button>
                </div>
            </form>
        </div>
    </div>

    <hr>

    <div class="card">
        <div class="card-header text-danger">سحب سلفة</div>

        <div class="card-body">
            <form action="<?php echo e(route('withdrawals.store', $employee)); ?>" method="post">
                <?php echo csrf_field(); ?>

                <div class="form-group text-danger">
                    <label class="required" for="withdrawal">السلفة</label>
                    <input class="form-control <?php echo e($errors->has('withdrawal') ? 'is-invalid' : ''); ?>" type="number"
                        name="withdrawal" id="withdrawal" value="<?php echo e(old('withdrawal')); ?>" required>
                    <?php if($errors->has('withdrawal')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('withdrawal')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <label class="required" for="notes">Notes</label>
                    <input class="form-control <?php echo e($errors->has('notes') ? 'is-invalid' : ''); ?>" type="text"
                        name="notes" id="notes" value="<?php echo e(old('notes')); ?>">
                    <?php if($errors->has('notes')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('notes')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"> </span>
                </div>

                <div class="form-group">
                    <button class="btn btn-primary" type="submit">
                        Save
                    </button>
                </div>
            </form>
        </div>
    </div>

    <hr>

    <div class="card">
        <div class="card-header">السلف السابقة</div>

        <?php if(session('status')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <div class="card-body">
            <table class="table table-responsive-sm">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th class="text-danger">السلفة</th>
                        <th>Notes</th>
                        <th>التاريخ</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody class="table-secondary">
                    <?php $__currentLoopData = $withdrawals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdrawal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($withdrawal->withdrawal); ?></td>
                            <td><?php echo e($withdrawal->notes); ?></td>
                            <td><?php echo e($withdrawal->created_at->format('Y-m-d')); ?></td>
                            <td>
                                <form action="<?php echo e(route('withdrawals.destroyOne', $withdrawal)); ?>" method="POST"
                                    onsubmit="return confirm('Are your sure?');" style="display: inline-block;">
                                    <input type="hidden" name="_method" value="DELETE">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <input type="submit" class="btn btn-sm btn-danger" value="Delete">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROJECTS\hachem_restaurant\resources\views/employees/edit.blade.php ENDPATH**/ ?>